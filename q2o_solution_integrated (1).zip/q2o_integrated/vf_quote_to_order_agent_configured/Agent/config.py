import os
from pathlib import Path

## Load .env from the project root (the folder above Agent/).
## Uses python-dotenv if installed; otherwise falls back to a tiny parser
## so the agent still works without the extra dependency.
_ENV_FILE = Path(__file__).resolve().parent.parent / ".env"
try:
    from dotenv import load_dotenv
    load_dotenv(_ENV_FILE)
except ImportError:
    if _ENV_FILE.is_file():
        for line in _ENV_FILE.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, _, value = line.partition("=")
            os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))

PROJECT_ID = os.getenv("GCP_PROJECT_ID", "vf-ie-aib-prd-iei-cfa-lab")
REGION = os.getenv("GCP_REGION", "europe-west1")
LLM_PROXY_ENDPOINT = os.getenv(
    "LLM_PROXY_ENDPOINT",
    "https://proxy-service-1034231601515.europe-west1.run.app",
)

## Full GCS path to the folder containing one subfolder per opportunity id.
## Examples:
##   gs://vfie-dh-customer-fixed
##   gs://vfie-dh-customer-fixed/parsed/opportunities
GCS_BASE_PATH = os.getenv("GCS_BASE_PATH", "gs://vfie-dh-customer-fixed")


def _parse_gcs_path(path: str) -> tuple[str, str]:
    """Split 'gs://bucket/optional/prefix' into (bucket, prefix)."""
    path = path.strip().removeprefix("gs://").strip("/")
    bucket, _, prefix = path.partition("/")
    return bucket, prefix


GCS_BUCKET_NAME, GCS_BASE_PREFIX = _parse_gcs_path(GCS_BASE_PATH)

# BigQuery (BSP internal validation) - direct access via google-cloud-bigquery
BQ_PROJECT = os.getenv("BQ_PROJECT", "vf-ie-aib-prd-iei-cfa-lab")
BQ_DATASET = os.getenv(
    "BQ_DATASET",
    "vf-ie-datahub.vfie_dh_lake_customer_complex_fixed_s",
)

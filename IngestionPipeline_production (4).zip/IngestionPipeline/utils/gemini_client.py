"""gemini_client.py — Gemini via Vodafone LLM Proxy"""

import logging

from google import genai
from google.genai.types import HttpOptions
import google.oauth2.id_token
from google.genai import types

from tenacity import (
    retry,
    stop_after_attempt,
    wait_exponential,
    retry_if_exception,
)

logger = logging.getLogger(__name__)


def _is_retryable(exc: BaseException) -> bool:
    """Retry transient failures only. Retrying a 400/safety-block 3x per
    file just multiplies cost and latency with zero chance of success."""
    if isinstance(exc, (ConnectionError, TimeoutError)):
        return True
    code = getattr(exc, "code", None) or getattr(exc, "status_code", None)
    return code in (408, 429, 500, 502, 503, 504)


class GeminiClient:

    def __init__(
        self,
        project_id: str,
        location: str,
        model_name: str,
        proxy_url: str,
        temperature: float = 0.1,
        max_output_tokens: int = 8192,
    ):
        self._model_name = model_name
        self._temperature = temperature
        self._max_output_tokens = max_output_tokens

        api_endpoint = f"{proxy_url}/google-llm"

        # Per-request cap (ms). Without it a single hung call can silently
        # consume the entire run's time budget.
        REQUEST_TIMEOUT_MS = 120_000

        id_creds = google.oauth2.id_token.fetch_id_token_credentials(
          api_endpoint
          )

        self.client = genai.Client(
            vertexai=True,
            project=project_id,
            location=location,
            credentials=id_creds,
            http_options=HttpOptions(
                base_url=api_endpoint,
                api_version="v1beta1",
                timeout=REQUEST_TIMEOUT_MS,
            ),
        )

    def _gen_config(self) -> types.GenerateContentConfig:
        # NOTE: previously temperature / max_output_tokens from config.yaml
        # were never passed to the API at all. response_mime_type forces
        # valid JSON so no markdown-fence stripping (and its failure modes)
        # is needed downstream.
        kwargs = dict(
            temperature=self._temperature,
            max_output_tokens=self._max_output_tokens,
            response_mime_type="application/json",
        )
        # gemini-2.5-flash enables dynamic "thinking" by default: those
        # tokens are billed at a higher rate AND count against the output
        # budget. Deterministic extraction gains nothing from it. Pro
        # models reject a zero budget, so only disable on flash.
        if "flash" in self._model_name:
            kwargs["thinking_config"] = types.ThinkingConfig(thinking_budget=0)
        return types.GenerateContentConfig(**kwargs)

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=30),
        retry=retry_if_exception(_is_retryable),
        reraise=True,
    )
    def _generate(self, contents) -> str:
        response = self.client.models.generate_content(
            model=self._model_name,
            contents=contents,
            config=self._gen_config(),
        )
        if response.text is None:
            # Happens on MAX_TOKENS truncation or a safety block. Without
            # this guard, None propagates and crashes in .strip() downstream
            # with an unhelpful AttributeError.
            finish = None
            if getattr(response, "candidates", None):
                finish = getattr(response.candidates[0], "finish_reason", None)
            raise RuntimeError(
                f"Gemini returned no text (finish_reason={finish}) — "
                "likely output truncation or a safety block"
            )
        return response.text

    # def extract_from_text(
    #     self,
    #     text: str,
    #     system_prompt: str,
    #     ) -> str:

    #     prompt = f"""
    #     {system_prompt}

    #     ---

    #     {text}
    #     """

    #     return self._generate(prompt)


    def extract_from_text(
        self,
        text: str,
        system_prompt: str,
        ) -> str:

        prompt = f"""
        {system_prompt}

        [USER INPUT-START]
        {text}
        [USER INPUT-END]
        """

        return self._generate(prompt)

    def extract_from_image_bytes(
            self,
            image_bytes: bytes,
            mime_type: str,
            system_prompt: str,
        ) -> str:

        image_part = types.Part.from_bytes(
            data=image_bytes,
            mime_type=mime_type,
        )
        return self._generate([system_prompt, image_part])

    def extract_from_pdf_bytes(
        self,
        pdf_bytes: bytes,
        system_prompt: str,
    ) -> str:

        pdf_part = types.Part.from_bytes(
            data=pdf_bytes,
            mime_type="application/pdf",
        )
        return self._generate([system_prompt, pdf_part])

GENERIC_JSON_PROMPT = """
You are a precise document data extraction assistant.
Analyze the provided document and extract ALL key information.

Return ONLY a valid JSON object — no markdown fences, no extra text.
Structure the JSON logically based on the document type.

Required top-level keys (add more as needed):
{
  "document_type": "<invoice | receipt | contract | report | form | email | other>",
  "extracted_fields": { ... },   // every field you can identify
  "line_items": [ ... ],         // table rows if present, else []
  "dates": [ ... ],              // all dates found
  "amounts": [ ... ],            // all monetary amounts found
  "parties": [ ... ],            // people / organisations mentioned
  "summary": "<one paragraph>",
  "confidence": "<high | medium | low>"
}
""".strip()


EXCEL_LAYOUT_PROMPT = """
You are a spreadsheet structure analyst. You will receive a raw cell dump from
one or more sheets of a workbook. Each line is one non-empty cell, formatted as:

  [sheet_name] R<row>C<col>: <value>

Row/col numbers are 1-indexed and reflect the cell's real position in the sheet —
there is no guarantee that data starts at row 1 / column 1, that columns line up
between sheets, or that a sheet contains only one logical block of data.

Your job is to figure out, per sheet, what kind of layout it is and extract the
data accordingly. Two layouts are common:

  - "form"  > label/value pairs (a label cell and a value cell, often with
              section headers above groups of labels). Example: "Customer Name"
              in one cell, the actual customer's name in an adjacent cell.
  - "table" > a header row followed by repeated data rows, column-aligned.
              There may be more than one table on a sheet (e.g. a small
              metadata table followed by a large records table further down
              or to the right), and tables may have a banner/title/version
              text above them that is not part of the data.

A single sheet can also be "mixed" (e.g. a form block followed by a table
block below it) — split it into separate blocks rather than forcing one shape.

Ignore purely decorative cells (color banners, version stamps, watermark-style
text with no neighboring data) — do not invent records out of them.

Return ONLY a valid JSON object — no markdown fences, no extra text — shaped
exactly like this:

{
  "sheets": [
    {
      "sheet_name": "<name>",
      "blocks": [
        {
          "layout": "form" | "table",
          "title": "<best-guess label for this block, e.g. 'Customer Information' or null>",
          "fields": { "<label>": "<value>", ... },   // ONLY for layout == "form", else {}
          "columns": ["<col1>", "<col2>", ...],        // ONLY for layout == "table", else []
          "rows": [ { "<col1>": "<val>", ... }, ... ],  // ONLY for layout == "table", else []
          "notes": "<anything ambiguous you had to guess, or null>"
        }
      ]
    }
  ],
  "confidence": "<high | medium | low>"
}

Rules:
- Every form label becomes a key in "fields" with its associated value as a string.
- Every table row becomes one object in "rows" keyed by the header in "columns".
- If a value cell is blank/empty, still include the key with an empty string.
- Do not merge unrelated blocks together. Do not drop a block just because it's small.
- Preserve the data's own wording for labels/headers; do not rename or normalize them.
""".strip()


EMAIL_JSON_PROMPT = """
You are an email parsing assistant.
Extract all meaningful information from the provided email content.

Return ONLY a valid JSON object — no markdown fences, no extra text.

{
  "subject": "",
  "from": "",
  "to": [],
  "cc": [],
  "date": "",
  "body_summary": "",
  "key_topics": [],
  "action_items": [],
  "entities": {
    "people": [],
    "organizations": [],
    "dates": [],
    "amounts": []
  },
  "sentiment": "<positive | neutral | negative>",
  "priority": "<high | medium | low>",
  "attachments_mentioned": []
}
""".strip()



"""
backfill.py — drain the processing backlog by running the pipeline locally
(e.g. on a VM) with no wall-clock budget, instead of waiting ~2 months of
daily 450-second scheduled runs.

Safe properties:
  - Fully resumable: state is saved after every batch, so Ctrl+C or a crash
    loses at most one in-flight batch. Just run it again.
  - Holds (and renews) the run lock, so scheduled Cloud Run invocations
    return 409 instead of racing it.
  - Loops until nothing is pending: persistent failures dead-letter after
    max_file_attempts and stop being retried, so the loop terminates.

Usage (from the project folder, with ADC or the pipeline SA):
  pip install -r requirements.txt
  python backfill.py                # default worker count from config
  python backfill.py --workers 8    # bump parallelism for the backfill
  python backfill.py --limit 20     # small trial batch first (recommended)
"""

import argparse
import logging
import time

from utils.config_loader import load_config
from pipeline import IngestionPipeline

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s — %(message)s",
)
logger = logging.getLogger("backfill")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--workers", type=int, default=None,
                    help="override runtime.max_workers for the backfill")
    ap.add_argument("--limit", type=int, default=None,
                    help="process at most N files then stop (trial runs)")
    ap.add_argument("--folder", default=None,
                    help="restrict sync+parse to one subfolder, e.g. --folder opp123")
    args = ap.parse_args()

    cfg = load_config()
    # No Cloud Run timeout here — remove the wall-clock budget.
    cfg.runtime.max_runtime_seconds = 10**9
    if args.workers:
        cfg.runtime.max_workers = args.workers

    pipeline = IngestionPipeline(cfg)

    grand_processed = grand_errors = batch_no = 0
    started = time.monotonic()

    while True:
        batch_no += 1
        result = pipeline.run(limit=args.limit, folder=args.folder)

        if result["status"] == "locked":
            logger.warning("Another run holds the lock — retrying in 60s")
            time.sleep(60)
            continue

        p, e = len(result["processed"]), len(result["errors"])
        d = len(result["dead_lettered"])
        grand_processed += p
        grand_errors += e
        elapsed = time.monotonic() - started
        rate = grand_processed / elapsed * 3600 if elapsed else 0
        logger.info(
            "pass %d: processed=%d errors=%d dead_lettered=%d | "
            "TOTAL processed=%d errors=%d | %.0f files/hour",
            batch_no, p, e, d, grand_processed, grand_errors, rate,
        )

        if args.limit:
            logger.info("--limit given, stopping after one pass")
            break
        if p == 0 and e == 0:
            logger.info(
                "Backlog drained in %.1f min — %d processed, "
                "%d ended in error (see ledger last_error / dead-letter list)",
                elapsed / 60, grand_processed, grand_errors,
            )
            break
        time.sleep(2)  # brief pause between passes (retries, new syncs)


if __name__ == "__main__":
    main()

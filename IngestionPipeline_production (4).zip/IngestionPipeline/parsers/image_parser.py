import json
import logging
from typing import Dict, Any

from utils.gemini_client import GeminiClient, GENERIC_JSON_PROMPT
from google.genai import types

logger = logging.getLogger(__name__)


class ImageParser:
    def __init__(self, gemini: GeminiClient):
        self.gemini = gemini

    def parse(
        self,
        image_bytes: bytes,
        filename: str,
        mime_type: str,
    ) -> Dict[str, Any]:

        raw = self.gemini.extract_from_image_bytes(
            image_bytes=image_bytes,
            mime_type=mime_type,
            system_prompt=GENERIC_JSON_PROMPT,
        )

        try:
            clean = (
                raw.strip()
                .removeprefix("```json")
                .removeprefix("```")
                .removesuffix("```")
                .strip()
            )
            return json.loads(clean)

        except Exception:
            logger.warning("[Image] Could not parse JSON for %s", filename)

            return {
                "raw_extraction": raw,
                "parse_error": True,
                "_meta": {
                    "source_file": filename,
                    "mime_type": mime_type,
                },
            }
"""
parsers/pdf_parser.py

Handles two PDF flavours:
  1. Text-based PDF  > extract text with PyMuPDF, send to Gemini as text
  2. Image-based PDF > render each page as a PNG, send to Gemini vision
     (or use Gemini's native PDF understanding if the file is small enough)

Strategy selection is automatic: if extracted text is too sparse, fall back
to image mode.
"""

import io
import json
import logging
from typing import Dict, Any

import fitz  # PyMuPDF

from utils.gemini_client import GeminiClient, GENERIC_JSON_PROMPT

logger = logging.getLogger(__name__)

# Minimum characters per page to consider the PDF "text-based"
TEXT_DENSITY_THRESHOLD = 50


class PDFParser:
    def __init__(self, gemini: GeminiClient):
        self.gemini = gemini

    def parse(self, file_bytes: bytes, filename: str) -> Dict[str, Any]:
        """Parse a PDF and return a structured dict ready to be saved as JSON."""
        doc = fitz.open(stream=file_bytes, filetype="pdf")
        total_pages = len(doc)
        avg_chars = self._average_text_length(doc)

        logger.info(
            "[PDF] %s — %d page(s), avg %.0f chars/page",
            filename, total_pages, avg_chars,
        )

        if avg_chars >= TEXT_DENSITY_THRESHOLD:
            extracted = self._parse_text_pdf(doc, file_bytes, filename)
        else:
            extracted = self._parse_image_pdf(doc, file_bytes, filename)

        doc.close()
        extracted["_meta"] = {
            "source_file": filename,
            "total_pages": total_pages,
            "parse_strategy": "text" if avg_chars >= TEXT_DENSITY_THRESHOLD else "image",
        }
        return extracted



    def _parse_text_pdf(
        self, doc: fitz.Document, file_bytes: bytes, filename: str
    ) -> Dict[str, Any]:
        """Extract text from all pages and let Gemini structure it."""
        pages_text = []
        for page in doc:
            pages_text.append(page.get_text("text"))

        full_text = "\n\n".join(pages_text)

        # We already have the text — sending it costs a fraction of what the
        # native PDF part costs (native PDFs are billed as ~258 image tokens
        # per page on top of the text). Reserve native PDF handling for
        # image-based documents where there is no text to extract.
        logger.info("[PDF] Sending extracted text to Gemini for %s", filename)
        raw = self.gemini.extract_from_text(full_text, GENERIC_JSON_PROMPT)

        return self._safe_parse_json(raw, filename)


    def _parse_image_pdf(
        self, doc: fitz.Document, file_bytes: bytes, filename: str
    ) -> Dict[str, Any]:
        """
        Render each page to a PNG image and send to Gemini vision.
        For multi-page docs we combine results page by page and merge.
        """
        # First try: send the whole PDF as a native document part
        if len(file_bytes) <= 20 * 1024 * 1024:
            logger.info(
                "[PDF] Image-based — using Gemini native PDF part for %s", filename
            )
            raw = self.gemini.extract_from_pdf_bytes(file_bytes, GENERIC_JSON_PROMPT)
            return self._safe_parse_json(raw, filename)

        # Fallback: render page by page
        logger.info("[PDF] Image-based — rendering pages for %s", filename)
        page_results = []
        for page_num, page in enumerate(doc):
            mat = fitz.Matrix(2.0, 2.0)  # 2× zoom > ~144 dpi
            pix = page.get_pixmap(matrix=mat, alpha=False)
            img_bytes = pix.tobytes("png")

            prompt = (
                f"{GENERIC_JSON_PROMPT}\n\n"
                f"(This is page {page_num + 1} of {len(doc)} from file: {filename})"
            )
            raw = self.gemini.extract_from_image_bytes(img_bytes, "image/png", prompt)
            page_results.append(self._safe_parse_json(raw, f"{filename}:page{page_num+1}"))

        return self._merge_page_results(page_results)


    @staticmethod
    def _average_text_length(doc: fitz.Document) -> float:
        if not doc:
            return 0.0
        total = sum(len(page.get_text("text").strip()) for page in doc)
        return total / len(doc)

    @staticmethod
    def _safe_parse_json(raw: str, label: str) -> Dict[str, Any]:
        """Safely parse JSON from Gemini response."""
        try:
            clean = raw.strip().lstrip("```json").lstrip("```").rstrip("```").strip()
            return json.loads(clean)
        except json.JSONDecodeError:
            logger.warning("[PDF] Could not parse JSON for %s, returning raw", label)
            return {"raw_extraction": raw, "parse_error": True}

    @staticmethod
    def _merge_page_results(pages: list) -> Dict[str, Any]:
        """Merge multi-page extraction results into a single dict."""
        if not pages:
            return {}
        if len(pages) == 1:
            return pages[0]

        merged = {
            "document_type": pages[0].get("document_type", "unknown"),
            "pages": pages,
            "extracted_fields": {},
            "line_items": [],
            "dates": [],
            "amounts": [],
            "parties": [],
            "summary": " | ".join(
                p.get("summary", "") for p in pages if p.get("summary")
            ),
        }
        for page in pages:
            merged["extracted_fields"].update(page.get("extracted_fields", {}))
            merged["line_items"].extend(page.get("line_items", []))
            merged["dates"].extend(page.get("dates", []))
            merged["amounts"].extend(page.get("amounts", []))
            merged["parties"].extend(page.get("parties", []))

        # Deduplicate lists
        merged["dates"] = list(dict.fromkeys(merged["dates"]))
        merged["amounts"] = list(dict.fromkeys(str(a) for a in merged["amounts"]))
        merged["parties"] = list(dict.fromkeys(merged["parties"]))
        return merged

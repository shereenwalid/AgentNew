import io
import logging
from typing import Dict, Any, List, Optional

import pandas as pd
from openpyxl import load_workbook

from utils.gemini_client import GeminiClient, EXCEL_LAYOUT_PROMPT

logger = logging.getLogger(__name__)

# Safety valve: if a workbook has more non-empty cells than this, don't send
# it to Gemini cell-by-cell — fall back to a straight pandas table load.

MAX_CELLS_FOR_GEMINI = 50000
MAX_CHARS_FOR_GEMINI = 100000

class ExcelParser:
    def __init__(self, gemini: Optional[GeminiClient] = None,
                 max_cells_for_gemini: int = MAX_CELLS_FOR_GEMINI):
        self.gemini = gemini
        self.max_cells_for_gemini = max_cells_for_gemini


    def parse(self, file_bytes: bytes, filename: str) -> Dict[str, Any]:
        """
        Parse an Excel file and return a structured JSON summary.
        All extracted data (tables and forms) is returned as JSON for
        the caller to save to GCS — no BigQuery insertion is performed.
        """
        # openpyxl (used by _dump_cells) cannot open legacy .xls at all —
        # previously these came back as "Empty or unreadable". Same for
        # binary .xlsb. CSV isn't a workbook — load it directly. .xlsm
        # works fine on the normal openpyxl path.
        lower = filename.lower()
        if lower.endswith(".csv"):
            logger.info("[Excel] %s — CSV, using direct pandas load", filename)
            return self._csv_load(file_bytes, filename)
        if lower.endswith((".xls", ".xlsb")):
            logger.info(
                "[Excel] %s — legacy/binary workbook, using direct pandas load",
                filename,
            )
            return self._fallback_table_load(file_bytes, filename)

        cells = self._dump_cells(file_bytes, filename)
        if not cells:
            logger.warning("[Excel] Empty or unreadable file: %s", filename)
            return {
                "_meta": {"source_file": filename, "rows_inserted": 0},
                "error": "Empty or unreadable file",
            }

        if self.gemini is None or len(cells) > self.max_cells_for_gemini:
            logger.info(
                "[Excel] %s — %d cells, skipping Gemini (no client or over "
                "%d-cell threshold), falling back to direct table load",
                filename, len(cells), self.max_cells_for_gemini,
            )
            return self._fallback_table_load(file_bytes, filename)
        
        try:
            structure = self._classify_with_gemini(cells, filename)
            return self._route_blocks(structure, filename)

        except Exception as exc:
            logger.warning(
                "[Excel] %s - Gemini failed (%s), using fallback load",
                filename,
                exc,
            )

            return self._fallback_table_load(
                file_bytes,
                filename,
            )

        # structure = self._classify_with_gemini(cells, filename)
        # return self._route_blocks(structure, filename)


    def _dump_cells(self, file_bytes: bytes, filename: str) -> List[str]:
        """
        Read every non-empty cell from every sheet and represent it as a
        position-tagged line: "[sheet_name] R<row>C<col>: <value>".

        This makes no assumption about where data starts, whether columns
        line up across sheets, or whether a sheet holds one table or five.
        """
        try:
            wb = load_workbook(io.BytesIO(file_bytes), data_only=True, read_only=True)
        except Exception as exc:
            logger.exception("[Excel] Failed to open workbook %s: %s", filename, exc)
            return []

        lines: List[str] = []
        for sheet in wb.worksheets:
            for row in sheet.iter_rows():
                for cell in row:
                    value = cell.value
                    if value is None:
                        continue
                    text = str(value).strip()
                    if not text:
                        continue
                    lines.append(f"[{sheet.title}] R{cell.row}C{cell.column}: {text}")
        wb.close()
        return lines


    # def _classify_with_gemini(self, cells: List[str], filename: str) -> Dict[str, Any]:
    #     dump_text = "\n".join(cells)
    #     raw = self.gemini.extract_from_text(dump_text, EXCEL_LAYOUT_PROMPT)
    #     return self._safe_parse_json(raw, filename)

    def _classify_with_gemini(self, cells: List[str], filename: str) -> Dict[str, Any]:
        dump_text = "\n".join(cells)

        logger.info(
            "[Excel] %s - %s cells, %s chars sent to Gemini",
            filename,
            len(cells),
            len(dump_text),
        )

        if len(dump_text) > MAX_CHARS_FOR_GEMINI:
            logger.info(
                "[Excel] %s - dump too large (%s chars), using fallback load",
                filename,
                len(dump_text),
            )
            raise ValueError("EXCEL_TOO_LARGE_FOR_GEMINI")

        raw = self.gemini.extract_from_text(
            dump_text,
            EXCEL_LAYOUT_PROMPT,
        )

        return self._safe_parse_json(raw, filename)


    def _route_blocks(self, structure: Dict[str, Any], filename: str) -> Dict[str, Any]:
        sheets = structure.get("sheets", [])
        if not sheets and "raw_extraction" in structure:
            return {
                "_meta": {"source_file": filename},
                "error": "Could not interpret sheet structure",
                "raw_extraction": structure["raw_extraction"],
            }

        form_blocks: List[Dict[str, Any]] = []
        table_blocks: List[Dict[str, Any]] = []

        for sheet in sheets:
            sheet_name = sheet.get("sheet_name", "Sheet1")
            for block in sheet.get("blocks", []):
                layout = block.get("layout")

                if layout == "table" and block.get("rows"):
                    table_blocks.append({
                        "sheet_name": sheet_name,
                        "title": block.get("title"),
                        "rows": block.get("rows"),
                        "notes": block.get("notes"),
                    })

                elif layout == "form" and block.get("fields"):
                    form_blocks.append({
                        "sheet_name": sheet_name,
                        "title": block.get("title"),
                        "fields": block.get("fields"),
                        "notes": block.get("notes"),
                    })

                else:
                    logger.warning(
                        "[Excel] %s — block on sheet '%s' had layout=%r with no "
                        "usable data, skipping",
                        filename, sheet_name, layout,
                    )

        summary: Dict[str, Any] = {
            "_meta": {
                "source_file": filename,
                "form_block_count": len(form_blocks),
                "table_block_count": len(table_blocks),
                "confidence": structure.get("confidence"),
            }
        }
        if form_blocks:
            summary["forms"] = form_blocks
        if table_blocks:
            summary["tables"] = table_blocks

        logger.info(
            "[Excel] %s — %d form block(s), %d table block(s) written as JSON",
            filename, len(form_blocks), len(table_blocks),
        )
        return summary


    def _fallback_table_load(self, file_bytes: bytes, filename: str) -> Dict[str, Any]:
        # openpyxl only reads .xlsx/.xlsm; legacy .xls needs xlrd, binary
        # .xlsb needs pyxlsb.
        lower = filename.lower()
        if lower.endswith(".xls"):
            engine = "xlrd"
        elif lower.endswith(".xlsb"):
            engine = "pyxlsb"
        else:
            engine = "openpyxl"
        try:
            sheets = pd.read_excel(io.BytesIO(file_bytes), sheet_name=None, engine=engine)
        except Exception as exc:
            logger.exception("[Excel] Fallback load failed for %s: %s", filename, exc)
            return {
                "_meta": {"source_file": filename},
                "error": "Empty or unreadable file",
            }

        table_blocks: List[Dict[str, Any]] = []

        for sheet_name, df in sheets.items():
            if df is None or df.empty:
                continue
            df = self._clean_dataframe(df, filename, sheet_name, title=None)
            table_blocks.append({
                "sheet_name": sheet_name,
                "title": None,
                "rows": self._json_safe_records(df),
                "notes": None,
            })

        summary: Dict[str, Any] = {
            "_meta": {
                "source_file": filename,
                "table_block_count": len(table_blocks),
                "parse_strategy": "fallback_direct_load",
            }
        }
        if table_blocks:
            summary["tables"] = table_blocks

        logger.info(
            "[Excel] %s — fallback load produced %d table block(s) as JSON",
            filename, len(table_blocks),
        )
        return summary


    def _csv_load(self, file_bytes: bytes, filename: str) -> Dict[str, Any]:
        """Load a CSV into the same table-blocks shape as workbook output."""
        try:
            df = pd.read_csv(
                io.BytesIO(file_bytes),
                sep=None, engine="python",       # sniff , ; \t delimiters
                encoding_errors="replace",
            )
        except Exception as exc:
            logger.exception("[Excel] CSV load failed for %s: %s", filename, exc)
            return {
                "_meta": {"source_file": filename},
                "error": "Empty or unreadable file",
            }

        if df.empty:
            return {"_meta": {"source_file": filename}, "error": "Empty file"}

        df = self._clean_dataframe(df, filename, "csv", title=None)
        return {
            "_meta": {
                "source_file": filename,
                "table_block_count": 1,
                "parse_strategy": "pandas_csv",
            },
            "tables": [{
                "sheet_name": "csv",
                "title": None,
                "rows": self._json_safe_records(df),
                "notes": None,
            }],
        }

    @staticmethod
    def _json_safe_records(df: pd.DataFrame) -> List[Dict[str, Any]]:
        """
        df.to_dict(orient="records") yields pd.Timestamp / NaT / NaN values
        that json.dumps cannot serialize (this is what made large workbooks
        'disappear' — the upload crashed after a successful parse).
        Round-tripping through pandas' own JSON encoder converts
        Timestamps to ISO strings and NaN/NaT to null.
        """
        import json as _json
        return _json.loads(df.to_json(orient="records", date_format="iso"))

    @staticmethod
    def _clean_dataframe(
        df: pd.DataFrame, filename: str, sheet_name: Optional[str], title: Optional[str]
    ) -> pd.DataFrame:
        df = df.dropna(how="all").dropna(axis=1, how="all")

        df.columns = [
            "col_" + str(c).strip().lower().replace(" ", "_").replace("-", "_")
            if str(c) and str(c)[0].isdigit()
            else str(c).strip().lower().replace(" ", "_").replace("-", "_")
            for c in df.columns
        ]

        df["_source_file"] = filename
        if sheet_name:
            df["_source_sheet"] = sheet_name
        if title:
            df["_block_title"] = title

        for col in df.select_dtypes(include=["object", "string"]).columns:
            df[col] = df[col].astype(str)

        return df


    @staticmethod
    def _safe_parse_json(raw: str, label: str) -> Dict[str, Any]:
        import json
        try:
            clean = raw.strip()
            if clean.startswith("```"):
                clean = clean.lstrip("`")
                if clean.lower().startswith("json"):
                    clean = clean[4:]
                clean = clean.rstrip("`").strip()
            return json.loads(clean)
        except json.JSONDecodeError:
            logger.warning("[Excel] Could not parse Gemini JSON for %s", label)
            return {"raw_extraction": raw, "parse_error": True}

"""Run the UI-only demo:  python run_ui.py   (or: streamlit run app.py)"""
import os, subprocess, sys
ROOT = os.path.dirname(os.path.abspath(__file__))
subprocess.run([sys.executable, "-m", "streamlit", "run", os.path.join(ROOT, "app.py"),
                "--server.port", os.getenv("UI_PORT", "8501"),
                "--server.headless", "true",
                "--browser.gatherUsageStats", "false"], cwd=ROOT, check=False)

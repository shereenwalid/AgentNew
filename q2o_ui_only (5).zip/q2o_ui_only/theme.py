"""Shared HTML head (Tailwind config, fonts, custom CSS) and global header,
lifted verbatim from Q2O_Anonymised.html / validationPage.html."""

import os

# UI-only demo: no agent API

TAILWIND_HEAD = """
<meta charset="utf-8">
<script src="https://cdn.tailwindcss.com?plugins=forms,container-queries,typography"></script>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@300;400;500;600&family=Hanken+Grotesk:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&display=swap" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js"></script>
<script>
tailwind.config = {
  darkMode: "class",
  theme: { extend: { colors: {
    primary: "#e60000", "primary-container": "#e60000",
    "background-light": "#f8f9fa", "surface-light": "#ffffff",
    "border-light": "#e5e7eb", "text-light": "#1f2937",
    "text-muted-light": "#6b7280", "sidebar-dark": "#333333", "sidebar-darker": "#222222",
    "tertiary": "#006823", "on-background": "#1a1c1c", "on-surface": "#1a1c1c",
    "on-surface-variant": "#5f3f3a", "surface-container-lowest": "#ffffff",
    "outline": "#946e68", "tertiary-fixed-dim": "#66df75", "primary-fixed": "#ffdad4",
    "inverse-on-surface": "#f1f1f1", "secondary-fixed": "#e4e2e1", "primary-fixed-dim": "#ffb4a8",
    "on-secondary-container": "#656464", "on-error-container": "#93000a",
    "on-primary-container": "#fff7f5", "surface-bright": "#f9f9f9",
    "on-tertiary": "#ffffff", "surface-variant": "#e2e2e2", "surface-tint": "#e60000",
    "on-secondary": "#ffffff", "error": "#ba1a1a", "error-container": "#ffdad6",
    "surface": "#f9f9f9", "on-error": "#ffffff", "secondary-container": "#e4e2e1",
    "inverse-primary": "#ffb4a8", "tertiary-fixed": "#83fc8e", "surface-dim": "#dadada",
    "surface-container-low": "#f3f3f3", "surface-container-high": "#e8e8e8",
    "on-tertiary-fixed-variant": "#00531a", "background": "#f9f9f9",
    "on-secondary-fixed-variant": "#474747", "on-primary-fixed-variant": "#930100",
    "tertiary-container": "#00842e", "surface-container-highest": "#e2e2e2",
    "on-tertiary-container": "#e5ffe0", "on-primary": "#ffffff",
    "outline-variant": "#e9bcb5", "surface-container": "#eeeeee",
    "inverse-surface": "#2f3131", "secondary": "#5f5e5e",
    "secondary-fixed-dim": "#c8c6c5", "on-surface-2": "#1a1c1c"
  },
  spacing: { "xs": "4px", "sm": "8px", "md": "16px", "lg": "24px", "xl": "32px" },
  borderRadius: { "DEFAULT": "4px" }
  } }
};
</script>
<style>
  html, body { height:100%; }
  body { font-family: 'Inter', sans-serif; margin:0; background:#f8f9fa; overflow:hidden; }
  #view-ingestion, #view-processing { overflow:hidden; }
  #view-validation, #view-results { height:100%; overflow-y:auto; }
  .material-symbols-outlined {
    font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24;
    display:inline-block; line-height:1; text-transform:none; letter-spacing:normal;
    word-wrap:normal; white-space:nowrap; direction:ltr;
  }
  .custom-scrollbar::-webkit-scrollbar { width:6px; height:6px; }
  .custom-scrollbar::-webkit-scrollbar-track { background:#f1f1f1; }
  .custom-scrollbar::-webkit-scrollbar-thumb { background:#c8c6c6; border-radius:10px; }
  .landing-hero-title { font-size:clamp(28px,3.5vw,40px); font-weight:700; color:#1a1a1a;
    letter-spacing:-0.025em; text-align:center; line-height:1.15; margin-bottom:12px; }
  .landing-hero-sub { font-size:15px; color:#5a5a5a; text-align:center; line-height:1.65;
    max-width:680px; margin:0 auto 24px auto; }
  .proc-modal { background:#ffffff; border-radius:12px; width:min(420px,90vw); padding:24px;
    box-shadow:0 12px 48px rgba(0,0,0,0.15); display:flex; flex-direction:column;
    align-items:center; gap:0; border:1px solid #e5e7eb; }
  .proc-title { font-size:17px; font-weight:700; color:#1f2937; letter-spacing:-0.02em;
    text-align:center; margin-bottom:4px; }
  .proc-echo { font-size:10px; font-family:'JetBrains Mono',monospace; color:#2563eb;
    display:inline-flex; align-items:center; gap:5px; margin-bottom:14px; text-align:center; }
  .proc-ring-wrap { position:relative; width:84px; height:84px; margin-bottom:14px;
    display:flex; align-items:center; justify-content:center; flex-shrink:0; }
  .proc-ring-wrap svg { position:absolute; inset:0; width:100%; height:100%; transform:rotate(-90deg); }
  .proc-pct-inner { position:relative; z-index:1; text-align:center; }
  .proc-pct-num { font-size:18px; font-weight:700; color:#1f2937; font-family:'JetBrains Mono',monospace; line-height:1; }
  .proc-pct-sym { font-size:11px; color:#9ca3af; vertical-align:super; }
  .proc-pct-label { font-size:7px; font-weight:700; text-transform:uppercase; letter-spacing:0.1em;
    color:#e60000; margin-top:3px; }
  .proc-status { font-size:11px; color:#4b5563; text-align:center; margin-bottom:2px; }
  .proc-timer { font-size:9px; font-family:'JetBrains Mono',monospace; color:#9ca3af;
    text-align:center; margin-bottom:14px; }
  .proc-steps { width:100%; max-width:340px; position:relative; }
  .proc-steps-track { position:absolute; left:9px; top:10px; bottom:10px; width:2px; background:#EEEEEE; }
  .proc-steps-fill { position:absolute; left:9px; top:10px; width:2px; background:#e60000;
    bottom:100%; transition:bottom 0.3s ease; }
  .proc-steps-list { display:flex; flex-direction:column; gap:9px; position:relative; z-index:1; }
  .proc-step { display:flex; align-items:flex-start; gap:10px; }
  .proc-node { width:20px; height:20px; border-radius:50%; border:2px solid #D0D0D0;
    display:flex; align-items:center; justify-content:center; flex-shrink:0; margin-top:1px;
    background:#F5F5F5; color:#AAAAAA; font-size:9px; font-weight:700; transition:all .25s; }
  .proc-node.done { background:#107c10; border-color:#107c10; color:#FFF; }
  .proc-node.active { background:#e60000; border-color:#e60000; color:#FFF;
    animation:nodeRing 2s ease-in-out infinite; }
  .proc-node.failed { background:#e60000; border-color:#e60000; color:#FFF; animation:none; }
  .proc-step-title { font-size:11px; font-weight:600; color:#9ca3af; transition:color .2s;
    line-height:1.25; margin-bottom:1px; }
  .proc-step-title.active-t { color:#e60000; font-weight:700; }
  .proc-step-title.done-t { color:#1f2937; }
  .proc-step-title.failed-t { color:#e60000; font-weight:700; }
  .proc-step-desc { font-size:9px; color:#9ca3af; line-height:1.25; }
  .proc-step-error { font-size:10px; color:#e60000; font-weight:700; margin-top:2px; line-height:1.3; }
  @keyframes nodeRing { 0%,100% { box-shadow:0 0 0 0 rgba(230,0,0,.35);} 50% { box-shadow:0 0 0 6px rgba(230,0,0,0);} }
  @keyframes spin { to { transform: rotate(360deg); } }
  .animate-spin { animation: spin 1s linear infinite; }
  .animate-pulse { animation: pulse 2s cubic-bezier(.4,0,.6,1) infinite; }
  @keyframes pulse { 0%,100%{opacity:1;} 50%{opacity:.5;} }
</style>
"""


def header_html(show_new_order=True):
    """Global dark header from Q2O_Anonymised.html."""
    btn = """
      <a href="?page=entry" target="_parent"
         class="bg-primary hover:bg-red-700 text-white font-medium py-1.5 px-4 rounded flex items-center justify-center text-xs transition-colors uppercase tracking-wider"
         style="font-family:'JetBrains Mono',monospace; text-decoration:none;">
        <span class="material-icons mr-1 text-sm">add</span> New Order
      </a>""" if show_new_order else ""
    return f"""
    <header class="bg-sidebar-dark text-white flex items-center justify-between px-6 py-3 border-b-2 border-primary shrink-0 z-50">
      <div class="flex items-center space-x-3">
        <div class="w-8 h-8 rounded-full bg-primary flex items-center justify-center">
          <span class="material-symbols-outlined text-white text-[18px]">receipt_long</span>
        </div>
        <div class="flex flex-col">
          <span class="font-bold text-sm leading-tight text-white">Quote to Order Drafting Agent</span>
          <span class="text-[9px] text-gray-400 font-mono tracking-wider uppercase">Sales Enablement Suite</span>
        </div>
      </div>
      <div class="flex items-center space-x-4">{btn}</div>
    </header>
    """


def page(body: str) -> str:
    """Wrap a body in the full HTML document."""
    return f"""<!DOCTYPE html>
<html class="light" lang="en"><head>{TAILWIND_HEAD}</head>
<body class="min-h-screen flex flex-col bg-[#f8f9fa] selection:bg-primary/20">
{body}
</body></html>"""

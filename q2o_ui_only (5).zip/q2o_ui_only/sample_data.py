"""Dummy data for the UI-only demo (no agent, no API).

Scenario is chosen from the opportunity id you type:
  - contains "SUCCESS" (or "PASS"/"OK")  -> everything passes
  - contains "KIT"                        -> a Kit order (no circuit checks)
  - anything else (e.g. "OPP-FAIL-123")   -> a failing Circuit order

Shape matches what the real agent API returns, including base_checks,
circuit_checks (only for circuit orders), per-check action, and pre-saved
human feedback so you can see how tracked status looks on re-runs.
"""

REQUIRED_LABELS = {
    "R1_po_signed_contract": "PO / signed contract",
    "R2_quote_to_customer": "Quote to customer",
    "R3_vendor_quote_clear_instruction": "Quote from vendor and clear instruction what vendor to order from",
    "R4_site_id": "Site ID",
    "R5_site_contact_info": "Site contact information",
    "R6_summary_sold_designed_hld": "Summary of what has been sold and/or Design / HLD if Solution Design involved",
    "R7_summary_content_complete": "Summary to include: services supplied, deployment, engineering asks/requirements, leadtime",
}

CHECK_LABELS = {
    "C1_leadtime_aligned_kpis": "If Leadtime provided to customer, is it aligned to our Product KPIs",
    "C2_circuit_order_form_attached": "Is the Circuit Order Form attached?",
    "C3_po_quote_attached_signed": "Is the PO/Quote attached and is it signed?",
    "C4_vendor_clear": "Is it clear what vendor the order is for?",
    "C5_third_party_vendor_docs": "Third Party usage: (Eir Fibre, Eir UG, EIL and SAB, Enet, Siro, Ripplecom/Host) quotes attached?",
    "C6_infra_orders_product_speed": "Are the correct Infra orders attached (Sales Enablement) and correct re product and speed?",
    "C7_site_info_correct": "Is the site information correct Site ID, Site Name, Site Address?",
    "C8_site_contact_details": "Is the site contact details provided, name, email and mobile number?",
    "C9_summary_matches_design_form": "Does the summary/design of the order match the design and order form attached?",
    "C10_correct_customer_account": "Are they on the correct customer account/company name so they are billed correctly?",
    "C11_lan_ip_for_dia": "Has the customers LAN IP details been provided for DIA?",
    "C12_public_ip_range_approved": "Customer Public address range(s) request details - has this been approved?",
    "C13_standard_offering_slash30": "Customer requesting IP address ranges - standard offering is /30",
    "C14_kit_router_fulfilment": "Is the Kit correct, router compatible, fulfilment run rate or ship back correct?",
    "C15_power_antenna_cables_licences": "Are all power supplies, antennas, extension cables, Licences requested on the order?",
    "C16_third_party_install_in_quote": "Is the 3rd party installation included in the quote?",
    "C17_contract_term_matches": "Is the contract term provided and does it match the order?",
    "C18_bend_info_correct": "Has the B-End information if required been filled out and is it correct?",
    "C19_qos_af_ef_correct": "Has the QoS if required been filled out and is it correct? AF and EF % on order form",
    "C20_cease_details_included": "If services are to be ceased after the new service, cease details must be added.",
    "C21_upgrade_downgrade_stated": "If the order is an Upgrade/Downgrade this must be clearly stated.",
    "C22_referenced_files_attached": "If comments refer to a certain email or file, make sure it is attached.",
    "C23_vendor_quote_still_valid": "Is the vendor quote still valid (not out of date)?",
    "C24_vf_quote_to_customer_attached": "Is the VF Quote to Customer attached?",
    "C25_leadtime_indicated_to_customer": "What Leadtime (if any) have you indicated to the customer",
    "C26_vendor_quotations_attached": "Are the Vendor Quotations attached?",
    "C27_tech_spec_commercial_approval_margin": "Tech spec includes commercial approval incl. margin (pricing tool / EDRA / email)?",
}

BASE_CHECK_LABELS = {
    "B1_customer_name_in_bsp": "Customer name exists / matches in BSP (else raise MDG)",
    "B2_delivery_address_in_bsp": "Delivery address exists in BSP (else raise BSP Team)",
    "B3_billing_entity_matches": "Billing entity name matches bill_to_name in BSP (else raise MDG)",
    "B4_opp_ref_matches_vbop": "Opportunity ref in tech spec matches VBOP",
    "B5_po_number_consistent": "PO number consistent across VBOP / customer PO (or email confirmation)",
    "B6_cost_less_than_sell": "Vendor PO cost price < sell price (Vodafone quote & customer PO)",
    "B7_product_codes_in_docs": "Every tech spec product code present in vendor quote (or name found)",
    "B8_product_codes_in_bsp_mdm": "Every tech spec product code exists in BSP via MDM (else raise MDM)",
    "B9_quantities_align": "Quantities align across all files (vendor quote may be higher)",
    "B10_vendor_quote_not_expired": "Vendor quote still valid (within 30 days, not expired)",
    "B11_contact_details_complete": "Contact name & details in tech spec are complete",
    "B12_order_readiness": "Order readiness - aggregate of all base checks",
}

CIRCUIT_CHECK_LABELS = {
    "X1_contract_term_present": "Contract term present (circuit order form / tech spec)",
    "X2_premise_id_siro": "Premise ID present (required for SIRO vendors)",
    "X3_service_type_matches": "Service type present and matches supporting docs",
    "X4_speed_matches": "Speed present and matches customer order form",
    "X5_product_name_type_exist": "Product name and type exist",
    "X6_service_address_in_bsp": "Service address present and matches BSP (else raise BSP Team)",
    "X7_po_matches_vbop": "PO number in circuit order form matches VBOP",
    "X8_billing_freq_aligned": "Billing frequency present and aligned",
    "X9_po_type_recurring": "PO type set to Recurring",
}

# Which items fail (+ default action for base/circuit) in the failing demo
_FAIL_REQUIRED = {
    "R4_site_id": "Site ID not found in the tech spec or order form",
    "R5_site_contact_info": "No site contact block present in the documents",
}
_FAIL_CHECKS = {
    "C2_circuit_order_form_attached": "Circuit Order Form not attached to the opportunity",
    "C8_site_contact_details": "Contact mobile number missing (name and email found)",
    "C23_vendor_quote_still_valid": "Vendor quote expired on 30/06/2026 (older than today)",
}
_FAIL_BASE = {
    "B1_customer_name_in_bsp": ("No exact match in TEMP_company; closest 'Dept of Social Protn'", "raise_mdg"),
    "B8_product_codes_in_bsp_mdm": ("Product code JD092B not found in BSP via MDM", "raise_mdm"),
    "B10_vendor_quote_not_expired": ("Vendor quotation dated 30/05/2026 - older than 30 days", "raise_sales"),
}
_FAIL_CIRCUIT = {
    "X2_premise_id_siro": ("SIRO premise id missing on circuit order form", "raise_bsp"),
    "X6_service_address_in_bsp": ("Service address not found in TEMP_location", "raise_bsp"),
}

# A pre-saved feedback record, to show how tracked status looks on re-runs
_PRESAVED_FEEDBACK = {
    "B1_customer_name_in_bsp": {
        "option": "raise_mdg",
        "comment": "Logged MDG request REQ-88231 to create company record.",
        "saved_date": "2026-07-20",
        "by": "shereen.elmasry",
    },
}

DUMMY_ORDER_CIRCUIT = {
    "order_title": "Public Sector_New_eir_DIA 200Mbps_Department of Social Protection_SITE-44102",
    "order_type": "New",
    "order_category": "Circuit",
    "status": "Draft - Pending Review",
    "contract_signed_date": "02/07/2026",
    "customer_contact": "Aoife Brennan / aoife.brennan@example.ie / +353 87 555 0142",
    "location_count": "1",
    "external_reference_number": "OPP-0007063044",
    "company_code": "VFIE01",
    "bill_to_party": "Department of Social Protection",
    "ship_to_party": "Department of Social Protection - Kilmainham",
    "order_date": "15/07/2026",
    "sales_contact": "sean.omalley@vodafone.com",
    "account_manager": "Niamh Kelly",
    "short_description": "Public Sector_New_eir_DIA 200Mbps_Department of Social Protection_SITE-44102",
    "escalation_level_priority": "P3 - Standard",
    "customer_required_date": "28/08/2026",
    "customer_reference": "PO-4500219987 (signed 02/07/2026)",
    "description": (
        "Sales Specialist: Sean O'Malley\n"
        "Site Contact: Aoife Brennan, +353 87 555 0142, aoife.brennan@example.ie\n"
        "Submitter Notes: Install outside business hours. Migration from legacy circuit "
        "once new service delivered; cease request to follow.\n"
        "Delivery Address: Con Colbert House, Con Colbert Road, Kilmainham, Dublin 8, Eircode D08 XH90\n"
        "Additional Info: QoS profile AF 30% / EF 20% agreed.\n"
        "SITE ID: SITE-44102"
    ),
    "device_services": "IP VPN - Managed WAN",
    "line_items": [
        {"quantity": 1, "item": "eir Fibre DIA 200Mbps - 36 month term", "sku": "TEL-DIA-200",
         "location": "Kilmainham, Dublin 8", "price": "545.00", "charge_type": "Recurring",
         "recurring_period": "Monthly", "fulfilment": "DIA-200-S"},
        {"quantity": 1, "item": "SLA", "sku": "SLA", "location": "Kilmainham, Dublin 8",
         "price": "45.00", "charge_type": "Recurring", "recurring_period": "Monthly", "fulfilment": "SLA-GOLD"},
        {"quantity": 1, "item": "ECS-INSTALL", "sku": "ECS-INSTALL", "location": "Kilmainham, Dublin 8",
         "price": "350.00", "charge_type": "One Off", "recurring_period": "Not Applicable", "fulfilment": "H202"},
        {"quantity": 1, "item": "ECS-INTSAndConfigIRL", "sku": "ECS-INTSAndConfigIRL",
         "location": "Kilmainham, Dublin 8", "price": "500.00", "charge_type": "One Off",
         "recurring_period": "Not Applicable", "fulfilment": "H202"},
        {"quantity": 2, "item": "Cisco C1111-8P Managed Router", "sku": "JD092B",
         "location": "Kilmainham, Dublin 8", "price": "139.18", "charge_type": "One Off",
         "recurring_period": "Not Applicable", "fulfilment": ""},
        {"quantity": 1, "item": "Managed WAN Software Licence - 36 months", "sku": "LIC-MWAN-36",
         "location": "Kilmainham, Dublin 8", "price": "18.00", "charge_type": "Recurring",
         "recurring_period": "Monthly", "fulfilment": "J404"},
        {"quantity": 4, "item": "CAT6 Extension Cable 5m", "sku": "CBL-C6-5M",
         "location": "Kilmainham, Dublin 8", "price": "12.00", "charge_type": "One Off",
         "recurring_period": "Not Applicable", "fulfilment": ""},
    ],
}

DUMMY_ORDER_KIT = {
    "order_title": "Enterprise_New_Cisco_Managed Router Kit_Acme Manufacturing_SITE-77310",
    "order_type": "New",
    "order_category": "Kit",
    "status": "Draft - Pending Review",
    "contract_signed_date": "05/07/2026",
    "customer_contact": "David Ryan / david.ryan@acme.ie / +353 86 555 0199",
    "location_count": "2-5",
    "external_reference_number": "OPP-0007099021",
    "company_code": "VFIE01",
    "bill_to_party": "Acme Manufacturing Ltd",
    "ship_to_party": "Acme Manufacturing Ltd - Cork",
    "order_date": "15/07/2026",
    "sales_contact": "mary.walsh@vodafone.com",
    "account_manager": "Ciaran Doyle",
    "short_description": "Enterprise_New_Cisco_Managed Router Kit_Acme Manufacturing_SITE-77310",
    "escalation_level_priority": "P3 - Standard",
    "customer_required_date": "30/08/2026",
    "customer_reference": "PO-4500220145",
    "description": (
        "Sales Specialist: Mary Walsh\n"
        "Site Contact: David Ryan, +353 86 555 0199, david.ryan@acme.ie\n"
        "Submitter Notes: Hardware kit only - customer self-installs.\n"
        "Delivery Address: Unit 4, Eastgate Business Park, Little Island, Cork, Eircode T45 KX28\n"
        "Additional Info: Includes spare PSU and mounting kit."
    ),
    "device_services": "System Integration",
    "line_items": [
        {"quantity": 3, "item": "Cisco C1111-8P Managed Router", "sku": "JD092B",
         "location": "Little Island, Cork", "price": "139.18", "charge_type": "One Off",
         "recurring_period": "Not Applicable", "fulfilment": "H202"},
        {"quantity": 3, "item": "Router Power Supply Unit (spare)", "sku": "PWR-C1-35W",
         "location": "Little Island, Cork", "price": "42.50", "charge_type": "One Off",
         "recurring_period": "Not Applicable", "fulfilment": "H202"},
        {"quantity": 3, "item": "Rack Mount Kit", "sku": "ACS-1100-RM",
         "location": "Little Island, Cork", "price": "25.00", "charge_type": "One Off",
         "recurring_period": "Not Applicable", "fulfilment": ""},
        {"quantity": 3, "item": "Managed WAN Software Licence - 36 months", "sku": "LIC-MWAN-36",
         "location": "Little Island, Cork", "price": "18.00", "charge_type": "Recurring",
         "recurring_period": "Monthly", "fulfilment": "J404"},
    ],
}


def _items(labels, all_pass, fail_map):
    out = {}
    for key in labels:
        if (not all_pass) and key in fail_map:
            val = fail_map[key]
            note, action = (val if isinstance(val, tuple) else (val, "none"))
            entry = {"result": "N", "notes": note, "action": action}
        else:
            entry = {"result": "Y", "notes": "Verified against documents / BSP", "action": "none"}
        if key in _PRESAVED_FEEDBACK:
            entry["feedback"] = _PRESAVED_FEEDBACK[key]
        out[key] = entry
    return out


def dummy_result(opp_id: str) -> dict:
    """Canned result in the same shape the real agent API returns."""
    upper = (opp_id or "").upper()
    all_pass = any(t in upper for t in ("SUCCESS", "PASS", "OK"))
    is_kit = "KIT" in upper

    validation = {
        "matched_folder": f"4231-opp-{opp_id}",
        "order_category": "Kit" if is_kit else "Circuit",
        "required_information": _items(REQUIRED_LABELS, all_pass, _FAIL_REQUIRED),
        "checks": _items(CHECK_LABELS, all_pass, _FAIL_CHECKS),
        "bsp_base_checks": _items(BASE_CHECK_LABELS, all_pass, _FAIL_BASE),
    }
    if not is_kit:
        validation["circuit_checks"] = _items(CIRCUIT_CHECK_LABELS, all_pass, _FAIL_CIRCUIT)

    order = dict(DUMMY_ORDER_KIT if is_kit else DUMMY_ORDER_CIRCUIT)
    order["external_reference_number"] = opp_id or order["external_reference_number"]

    return _shape(opp_id, validation, order, all_pass)


# ── mimic agent_api._shape_result so the UI gets identical structure ──
def _shape(opp_id, v, o, all_pass):
    def items(section, labels):
        out = []
        data = v.get(section, {}) or {}
        for key, label in labels.items():
            e = data.get(key, {}) or {}
            res = str(e.get("result", "N")).upper()
            out.append({
                "key": key, "label": label, "ok": res == "Y",
                "notes": e.get("notes", "") or ("Verified" if res == "Y" else "Not verified"),
                "action": e.get("action", "none") or "none",
                "feedback": e.get("feedback"),
            })
        return out

    order_category = v.get("order_category", "Not Specified")
    is_circuit = order_category.lower() == "circuit" or ("circuit_checks" in v)
    criteria = items("required_information", REQUIRED_LABELS)
    checks = items("checks", CHECK_LABELS)
    base_checks = items("bsp_base_checks", BASE_CHECK_LABELS)
    circuit_checks = items("circuit_checks", CIRCUIT_CHECK_LABELS) if is_circuit else []
    failed = [i for i in criteria + checks + base_checks + circuit_checks if not i["ok"]]

    return {
        "status": "ok",
        "opportunity_id": opp_id,
        "matched_folder": v.get("matched_folder", ""),
        "order_category": order_category,
        "is_circuit": is_circuit,
        "criteria": criteria,
        "checks": checks,
        "base_checks": base_checks,
        "circuit_checks": circuit_checks,
        "failed_count": len(failed),
        "overall": {"ready_for_order": "Y" if not failed else "N",
                    "blocking_issues": [i["label"] for i in failed], "needs_human_review": []},
        "order": o,
        "line_item_confidence": 96 if all_pass else 87,
    }

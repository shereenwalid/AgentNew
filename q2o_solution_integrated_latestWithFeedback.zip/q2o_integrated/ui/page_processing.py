"""View 2: Processing loader - exact markup from Q2O_Anonymised.html (hidden by default)."""

STEPS = [
    ("Ingest Quote Data", "Ingesting raw quote data and contractual documents..."),
    ("NLP Parsing", "Running NLP parser to extract quantities, schedules, and clauses..."),
    ("Order Acceptance", "Check Order Acceptance Criteria..."),
    ("Knowledge Cross-Check", "Communicate with product, code navigator and cross-check against knowledge base"),
    ("Data Integrity", "Evaluate data integrity"),
    ("Auto-Draft Order", "Auto-draft order in back office operations system"),
]


def view() -> str:
    steps_html = ""
    for i, (title, desc) in enumerate(STEPS, start=1):
        steps_html += f"""
        <div class="proc-step">
          <div class="proc-node" id="pn{i}"><span id="pi{i}">{i}</span></div>
          <div>
            <div class="proc-step-title" id="pt{i}">{title}</div>
            <div class="proc-step-desc">{desc}</div>
            <div class="proc-step-error" id="pe{i}" style="display:none;"></div>
          </div>
        </div>"""

    return f"""
    <div id="view-processing" style="display:none; min-height:calc(100vh - 62px); align-items:center; justify-content:center;
         background: radial-gradient(ellipse at center, rgba(230,0,0,0.08) 0%, rgba(18,18,18,0.15) 70%); padding:24px;">
      <div class="proc-modal">
        <h2 class="proc-title">Processing Quote to Order</h2>
        <p class="proc-echo" id="proc-echo">
          <span class="material-symbols-outlined animate-spin" style="font-size:14px;" id="echo-icon">sync</span>
          <span id="proc-echo-text">Analyzing Opportunity ID...</span>
        </p>
        <div class="proc-ring-wrap">
          <svg viewBox="0 0 100 100">
            <circle cx="50" cy="50" r="44" fill="none" stroke="#EEEEEE" stroke-width="3"/>
            <circle id="proc-ring-fill" cx="50" cy="50" r="44" fill="none" stroke="#e60000"
              stroke-linecap="round" stroke-width="5" stroke-dasharray="276.5" stroke-dashoffset="276.5"/>
            <circle cx="50" cy="50" r="36" fill="none" stroke="#FFCCCC" stroke-dasharray="3 9" stroke-width="1.5"
              style="animation:spin 4s linear infinite; transform-origin:50% 50%;"/>
          </svg>
          <div class="proc-pct-inner">
            <div class="proc-pct-num"><span id="progress-percent">0</span><span class="proc-pct-sym">%</span></div>
            <div class="proc-pct-label animate-pulse" id="pct-label">Processing</div>
          </div>
        </div>
        <p class="proc-status animate-pulse" id="proc-status">Ingesting raw data...</p>
        <p class="proc-timer" id="timer-label">Estimated remaining: calculating...</p>
        <div class="proc-steps">
          <div class="proc-steps-track"></div>
          <div class="proc-steps-fill" id="proc-fill-line"></div>
          <div class="proc-steps-list">{steps_html}</div>
        </div>
        <div id="fail-actions" style="display:none; margin-top:24px; width:100%; max-width:400px; flex-direction:column; gap:8px;">
          <button onclick="showSection('validation')"
             class="w-full bg-primary hover:bg-red-700 text-white font-medium py-2 px-6 rounded text-center text-xs uppercase tracking-wider"
             style="font-family:'JetBrains Mono',monospace;">
             View Validation
          </button>
          <button onclick="resetToLanding()"
             class="w-full bg-white border border-gray-300 hover:bg-gray-50 text-gray-700 font-medium py-2 px-6 rounded text-center text-xs uppercase tracking-wider"
             style="font-family:'JetBrains Mono',monospace;">
             Return to Order Entry
          </button>
        </div>
      </div>
    </div>
    """
